package edu.bu.met.cs665.models;

public class Americano extends Coffee {

	public Americano() {
		super("Americano");
	}
	
	

}
