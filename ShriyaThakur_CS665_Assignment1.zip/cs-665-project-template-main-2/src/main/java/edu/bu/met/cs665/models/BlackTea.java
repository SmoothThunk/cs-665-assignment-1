package edu.bu.met.cs665.models;

public class BlackTea extends Tea {

	public BlackTea() {
		super("Black Tea");
	}

}
