package edu.bu.met.cs665.models;

public class YellowTea extends Tea{

	public YellowTea() {
		super("Yellow Tea");
	}

}
