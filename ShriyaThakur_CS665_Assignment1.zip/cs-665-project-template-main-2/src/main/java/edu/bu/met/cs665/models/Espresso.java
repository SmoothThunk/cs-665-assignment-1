package edu.bu.met.cs665.models;

public class Espresso extends Coffee {

	public Espresso() {
		super("Espresso");
		// TODO Auto-generated constructor stub
	}
	
}
