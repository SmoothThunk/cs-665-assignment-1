package edu.bu.met.cs665.models;

import java.math.BigDecimal;

public abstract class Tea extends Beverage {

	public Tea(String name) {
		super(name, new BigDecimal("1.50")); 
	}
}