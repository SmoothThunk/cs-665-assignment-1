/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 09/25/2023
 * File Name: AutomatedBeverageMachine.java
 * Description: AutomatedBeverageMachine class for creating new Beverage objects.
 */
package edu.bu.met.cs665.models;

import java.math.BigDecimal;

/**
 * This is the AutomatedBeverageMachine class.
 * This class is responsible for:
 * 	- brewing beverages
 *  - adding condiments to a given beverage
 *  - calculating the cost of a given beverage
 */
public class AutomatedBeverageMachine {
	
	private BigDecimal sugarCost = new BigDecimal("0.50");
	private BigDecimal milkCost = new BigDecimal("0.25");
	
	public AutomatedBeverageMachine () {}

	/**
	 * Method for creating new beverage objects.
	 * 
	 * @param beverage - name of beverage user wants
	 * @return beverage object matching user input.
	 */
	public Beverage brew (String beverage) {
		Beverage brewed = null;
		if (beverage.equals("Americano")) {
			brewed = new Americano();
		} 
		else if (beverage.equals("Espresso")) {
			brewed = new Espresso();
		}
		else if (beverage.equals("Latte Macchiato")) {
			brewed = new LatteMacchiato();
		}
		else if (beverage.equals("Black Tea")) {
			brewed = new BlackTea();
		}
		else if (beverage.equals("Yellow Tea")) {
			brewed = new YellowTea();
		}
		else if (beverage.equals("Green Tea")) {
			brewed = new GreenTea();
		}
		return brewed;
	}
	
	/**
	 * Method for adding condiments to user's beverage.
	 * 
	 * @param beverage - beverage to be modified with condiments
	 * @param condiment - can be either sugar or milk, maximum of 3 units
	 * @param qty - units for selected condiment to be added to beverage
	 * @return modified beverage with specified condiments
	 */
	public Beverage addCondiment (Beverage beverage, String condiment, int qty) {
		if (qty > 3) {
			throw new IllegalArgumentException("Condiment quantity cannot exceed 3 units");
		}
		if (qty < 0) {
			throw new IllegalArgumentException("Condiment quantity cannot be negative");
		}
		
		if (condiment.equals("Milk")) {
			beverage.addMilk(qty);
		}
		else if (condiment.equals("Sugar")) {
			beverage.addSugar(qty);
		}
		
		return beverage;
	}
	
	/**
	 * Method to determine cost of a beverage based on type of beverage and condiments added.
	 * 
	 * @param beverage - beverage supplied by the user
	 * @return cost of the given beverage
	 */
	public BigDecimal calculateCostOfBeverage (Beverage beverage) {
		BigDecimal costOfBeverage = BigDecimal.ZERO;
		
		costOfBeverage = costOfBeverage.add(milkCost.multiply(BigDecimal.valueOf(beverage.getMilk())));
		costOfBeverage = costOfBeverage.add(sugarCost.multiply(BigDecimal.valueOf(beverage.getSugar())));
		costOfBeverage = costOfBeverage.add(beverage.getCost());
		
		return costOfBeverage; 
	}
	
	
}
