package edu.bu.met.cs665.models;

public class LatteMacchiato extends Coffee {

	public LatteMacchiato() {
		super("Latte Macchiato");
	}

}
