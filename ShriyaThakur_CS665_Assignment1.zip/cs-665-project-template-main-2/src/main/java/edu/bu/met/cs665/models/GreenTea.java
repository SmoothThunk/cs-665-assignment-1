package edu.bu.met.cs665.models;

public class GreenTea extends Tea {

	public GreenTea() {
		super("Green Tea");
	}

}
