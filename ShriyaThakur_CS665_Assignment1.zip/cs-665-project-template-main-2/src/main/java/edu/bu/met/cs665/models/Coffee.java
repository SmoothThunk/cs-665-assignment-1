package edu.bu.met.cs665.models;

import java.math.BigDecimal;

public abstract class Coffee extends Beverage {

	public Coffee(String name) {
		super(name, new BigDecimal("2.00"));
	}

}
