/**
 * Name: SHRIYA THAKUR
 * Course: CS-665 Software Designs & Patterns
 * Date: 09/25/2023
 * File Name: Main.java
 * Description: Main class for running application.
 */

package edu.bu.met.cs665;

import edu.bu.met.cs665.models.AutomatedBeverageMachine;
import edu.bu.met.cs665.models.Beverage;

/**
 * This is the Main class.
 */
public class Main {

  /**
   * A main method to run examples.
   * You may use this method for development purposes as you start building your
   * assignments/final project.  This could prove convenient to test as you are developing.
   * However, please note that every assignment/final projects requires JUnit tests.
   */
  public static void main(String[] args) {
    
	  // Testing main methods created for this project.
	  AutomatedBeverageMachine beverageMachine = new AutomatedBeverageMachine();
	  Beverage beverage = beverageMachine.brew("Latte Macchiato");
	  beverage = beverageMachine.addCondiment(beverage, "Milk", 3);
	  System.out.println("Beverage Info: " + beverage.toString());
	  System.out.println("Beverage Cost: $" + beverageMachine.calculateCostOfBeverage(beverage));
  }

}
