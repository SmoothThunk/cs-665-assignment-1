package edu.bu.met.cs665.models;

import static org.junit.Assert.*;

import java.math.BigDecimal;

import org.junit.Before;
import org.junit.Test;

/**
 * This is a test class for the AutomatedBeverageMachine class.
 * This class is reponsible for:
 *  - testing the brew method
 *  - testing the addCondiment method
 *  - testing the calculateCostOfBeverage method
 */
public class AutomatedBeverageMachineTest {
	
	AutomatedBeverageMachine beverageMachine;
	
	@Before
	public void setUp() throws Exception {
		beverageMachine = new AutomatedBeverageMachine();
	}

	@Test
	public void testBrew_Americano_Success() {
		// Given: an Americano object
		Beverage expectedBeverage = new Americano();
		// When: the beverage machine brews an Americano object
		Beverage actualBeverage = beverageMachine.brew("Americano");
		// Then: confirm the expected beverage matches the beverage brewed by the beverage machine
		assertEquals(expectedBeverage.getName(), actualBeverage.getName());
	}
	
	@Test
	public void testBrew_Espresso_Success() {
		Beverage expectedBeverage = new Espresso();
		Beverage actualBeverage = beverageMachine.brew("Espresso");
		assertEquals(expectedBeverage.getName(), actualBeverage.getName());
	}
	
	@Test
	public void testBrew_LatteMacchiato_Success() {
		Beverage expectedBeverage = new LatteMacchiato();
		Beverage actualBeverage = beverageMachine.brew("Latte Macchiato");
		assertEquals(expectedBeverage.getName(), actualBeverage.getName());
	}
	
	@Test
	public void testBrew_BlackTea_Success() {
		Beverage expectedBeverage = new BlackTea();
		Beverage actualBeverage = beverageMachine.brew("Black Tea");
		assertEquals(expectedBeverage.getName(), actualBeverage.getName());
	}
	
	@Test
	public void testBrew_YellowTea_Success() {
		Beverage expectedBeverage = new YellowTea();
		Beverage actualBeverage = beverageMachine.brew("Yellow Tea");
		assertEquals(expectedBeverage.getName(), actualBeverage.getName());
	}
	
	@Test
	public void testBrew_GreenTea_Success() {
		Beverage expectedBeverage = new GreenTea();
		Beverage actualBeverage = beverageMachine.brew("Green Tea");
		assertEquals(expectedBeverage.getName(), actualBeverage.getName());
	}
	
	@Test
	public void testAddCondiment_Milk_Success() {
		// Given: an Americano object with 3 units of milk added
		Beverage expectedBeverage = new Americano();
		expectedBeverage.setMilk(3);
		
		// When: the beverage machine adds condiments specified by the user
		Beverage condimentBeverage = new Americano();
		Beverage actualBeverage = beverageMachine.addCondiment(condimentBeverage, "Milk", 3);
		
		// Then: we confirm that both beverages have the same quantity of milk
		assertEquals(expectedBeverage.getMilk(), actualBeverage.getMilk());
	}
	
	@Test
	public void testAddCondiment_Sugar_Success() {
		Beverage expectedBeverage = new Americano();
		expectedBeverage.setSugar(3);
		
		Beverage condimentBeverage = new Americano();
		Beverage actualBeverage = beverageMachine.addCondiment(condimentBeverage, "Sugar", 3);
		
		assertEquals(expectedBeverage.getSugar(), actualBeverage.getSugar());
	}

	@Test
	public void testAddCondiment_Milk_Failure() {
		// Given: a test Americano object with no condiments added
		Beverage testBeverage = new Americano();
		
		// When: The specified unit of milk exceeds the limit of 3
		Exception ex = assertThrows (IllegalArgumentException.class, () -> {
			beverageMachine.addCondiment(testBeverage, "Milk", 5);
		});
		
		// Then: verify that the thrown exception message matches the expected error
		assertEquals("Condiment quantity cannot exceed 3 units", ex.getMessage());
	}
	
	@Test
	public void testAddCondiment_Sugar_Failure() {
		Beverage testBeverage = new Americano();
		
		Exception ex = assertThrows (IllegalArgumentException.class, () -> {
			beverageMachine.addCondiment(testBeverage, "Sugar", -1);
		});
				
		assertEquals("Condiment quantity cannot be negative", ex.getMessage());
	}
	
	@Test
	public void testCalculateCostOfBeverage_Success() {
		// Given: an expected cost of an Americano with 3 sugar and 2 milk
		BigDecimal expectedCost = new BigDecimal("4.00");
		Beverage testBeverage = beverageMachine.brew("Americano");
		beverageMachine.addCondiment(testBeverage, "Sugar", 3);
		beverageMachine.addCondiment(testBeverage, "Milk", 2);
		
		// When: the beverage machine calculates the cost of an Americano with 3 sugar and 2 milk
		BigDecimal actualCost = beverageMachine.calculateCostOfBeverage(testBeverage);
		
		// Then: verify that the expected cost matches the actual cost of the Americano object
		assertEquals(expectedCost, actualCost);
	}
	
	
}
